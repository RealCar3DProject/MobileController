To run the server first you need npm + node.js:
    https://www.npmjs.com/package/npm


After installing run the following commands:
    
    npm install
            will install all required packages for it to work.

    node server.js
            will run the server.
            
You can change used ports and other details in the file config.json.

ssl.cert and ssl.key contain the an example ssl certificate to allow 
using secure connections. Simply replace the files with your own
certificate!

Any problems setting up your own server?
Send a mail to contact@because-why-not.com or visit http://because-why-not.com !